var intervalo; // Variável para armazenar o intervalo do cronômetro
var tempoInicial = null; // Variável para armazenar o tempo inicial

$(document).ready(function() {
    // Manipulador de clique do botão "Iniciar"
    $('#btnIniciar').click(function() {
        iniciarCronometro();
    });

    // Manipulador de clique do botão "Zerar"
    $('#btnZerar').click(function() {
        pararCronometro();
        zerarCronometro();
    });

    // Verifica se o valor existe no localStorage
    if (localStorage.getItem('tempoInicial')) {
        tempoInicial = parseInt(localStorage.getItem('tempoInicial')); // Obtém o tempo inicial do localStorage

        // Calcula o tempo decorrido desde o tempo inicial
        var tempoAtual = Date.now();
        var tempoDecorrido = Math.floor((tempoAtual - tempoInicial) / 1000);

        // Atualiza o cronômetro com o tempo decorrido
        atualizarCronometro(tempoDecorrido);

        // Inicia o cronômetro
        iniciarCronometro();
    }
});

function iniciarCronometro() {
    if (tempoInicial === null) {
        tempoInicial = Date.now(); // Obtém o tempo atual em milissegundos

        // Armazena o tempo inicial no localStorage
        localStorage.setItem('tempoInicial', tempoInicial.toString());
    }

    // Atualiza o cronômetro a cada segundo
    intervalo = setInterval(function() {
        var tempoAtual = Date.now();
        var tempoDecorrido = Math.floor((tempoAtual - tempoInicial) / 1000);
        atualizarCronometro(tempoDecorrido);
    }, 1000);
}

function pararCronometro() {
    clearInterval(intervalo); // Limpa o intervalo do cronômetro
}

function zerarCronometro() {
    // Remove o valor do tempo inicial do localStorage
    localStorage.removeItem('tempoInicial');

    // Reinicia a variável de tempo inicial
    tempoInicial = null;

    // Atualiza o cronômetro com o tempo zerado
    atualizarCronometro(0);
}

function atualizarCronometro(tempoDecorrido) {
    // Atualiza o conteúdo da div "tempoExibido" com o tempo decorrido formatado
    $('#tempoExibido').text(formatarTempo(tempoDecorrido));
}

function formatarTempo(segundos) {
    var minutos = Math.floor(segundos / 60);
    var segundosRestantes = segundos % 60;

    return minutos.toString().padStart(2, '0') + ':' + segundosRestantes.toString().padStart(2, '0');
}
