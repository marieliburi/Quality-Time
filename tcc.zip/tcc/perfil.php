<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QualityTime</title>
    <style>
        *{
            padding: 0;
            margin: 0;
            font-family:Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        .image-container img{
           
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background-color: white;
        }
     
        h2{
            margin-left: 10px;
        }
        .descricao{
            width: 250px;
            margin-left: 10px;
        }
        
        .top{
            height: 200px;
            background-color:  rgb(112,15,28);
            display: flex;
            justify-content: center;
        }
        .image-container{
            background-color: white;
            width: 300px;
            height: 300px;
            padding: 5px;
            border-radius: 50%;
            margin-top: 40px;
        }
        input[type="file"]{
            display: none;
        }
        label{
            border: 2.5px solid rgb(60, 60, 60);
            margin-left: 10px;
            padding: 0.5rem;
            padding-left: 15px;
            padding-right: 15px ;
            width: 320px;
            color: rgb(60, 60, 60);
            display: flex;
            justify-content: space-between;
            align-items: center;
            text-align: center;
            border-radius: 5px;
        }
        label span:nth-child(2){
            color: white;
            background-color: rgb(60, 60, 60);
            padding: 1rem 1.5rem;
            border-radius: .2rem;
            cursor: pointer;
        }
        #btnEnviar{
            margin-left: 10px;
            width: 140px;
            height: 35px;
            background-color:  rgb(112,15,28);
            color:white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 17px;
        }
        #btnEnviar:hover, .btnVoltar:hover{
            background-color:  rgb(112,15,28);
        }
        .btnVoltar, #btnAtualizar, #btnExcluir{
            margin-left: 10px;
            display: flex;
            width: 140px;
            height: 35px;
            background-color:  rgb(112,15,28);
            color:white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            text-decoration: none;
            align-items: center;
            justify-content: center;
            font-size: 17px;
            margin-bottom: 10px;
        }
        a{
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="card-container">
        <div class="top">
            
        <div class="image-container">
        <img src="imagens/fotoPerfil.jpg" class="fotoPerfil"><br>
    </div>
    </div>
    <br>
    <div class="container">
        <form method="POST" action="salvar_foto .php" enctype="multipart/form-data">
            <input class="trocarFoto" name="foto_perfil" type="file" id="file">
            <label for="file">
                <span class="text">Selecionar imagem</span>
                <span>Procurar</span>
            </label>
            <br><button id="btnEnviar" type="submit">Enviar</button>
        </form>
        
    </div>
    <br>  
        <?php
        session_start();
        include('conexao.php');
    
        // Verifica se o usuário está logado
        if (isset($_SESSION['email'])) {
            $email = $_SESSION['email'];
    
            // Conecta-se ao banco de dados
            $conn = conectarBancoDeDados();
    
            // Escapa o email para prevenir SQL injection
            $email = mysqli_real_escape_string($conn, $email);
    
            // Consulta o banco de dados para obter os dados do usuário
            $query = "SELECT nome, telefone, email FROM usuario WHERE email = '$email'";
            $result = mysqli_query($conn, $query);
    
            // Verifica se a consulta foi bem-sucedida
            if ($result) {
                $row = mysqli_fetch_assoc($result);
                $nome = $row['nome'];
                $telefone = $row['telefone'];
                $email = $row['email'];
    
                // Exibe os dados do usuário na tela de perfil
                echo "<h2>$nome</h2>";
                echo "<p class='descricao'>Telefone: $telefone</p>";
                echo "<p class='descricao'>Email: $email</p>";
    
            }
    
            // Fecha a conexão com o banco de dados
            mysqli_close($conn);
        }
    ?>
    

        <br>
        <div class="btns">
            <a class="btnVoltar" href="principal.php">Voltar</a>
            <br><a href='atualiza.html'><button id='btnAtualizar'>Atualizar Dados</button></a>
            <button id="btnExcluir" class="btnExcluir">Deletar Conta</button>
        </div>    
    </div>
    <script>
        document.querySelector('#file').addEventListener('change', function(){
            document.querySelector('.text').textContent = this.files[0].name; 
        })
    </script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script>
       $(document).ready(function() {
            // Manipulador de clique do botão "Enviar"
            $('#btnEnviar').click(function() {
                var formData = new FormData();
                formData.append('foto_perfil', $('input[type=file]')[0].files[0]);

                // Realiza uma requisição AJAX para enviar a imagem ao servidor
                $.ajax({
                    type: 'POST',
                    url: 'salvar_foto.php',
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.caminho_imagem) {
                            // Atualiza a imagem exibida na tela com a nova imagem
                            $('#fotoPerfil').attr('src', response.caminho_imagem);
                        } else if (response.error) {
                            alert(response.error);
                        } else {
                            alert('Erro desconhecido ao salvar a imagem de perfil.');
                        }
                    },
                    error: function() {
                        alert('Erro ao enviar a imagem.');
                    }
                });
            });
        });

    </script>

<script>
    $(document).ready(function() {
        // Manipulador de clique do botão "Deletar Conta"
        $('#btnExcluir').click(function() {
            // Exibe a mensagem de confirmação
            if (confirm('Tem certeza que deseja deletar sua conta? Essa ação não pode ser desfeita.')) {
                // Realiza a requisição AJAX para deletar a conta
                $.ajax({
                    type: 'POST',
                    url: 'deletar_conta.php',
                    dataType: 'json',
                    success: function(response) {
                        // Verifica se a conta foi deletada com sucesso
                        if (response.success) {
                            // Conta deletada com sucesso
                            // Encaminha o usuário para a página inicial de entrada (index.html)
                            window.location.href = 'index.html';
                        } else {
                            // Exibe uma mensagem de erro
                            alert('Erro ao deletar a conta. Por favor, tente novamente.');
                        }
                    },
                    error: function() {
                        // Exibe uma mensagem de erro
                        alert('Erro ao enviar a requisição. Por favor, tente novamente.');
                    }
                });
            }
        });
    });
</script>


</body>
</html>