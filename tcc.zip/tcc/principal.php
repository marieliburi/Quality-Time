<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['email'])) {
  header('Location: index.html');
  exit;
}

// Função para destruir a sessão e redirecionar para a página de login
function logout() {
  session_destroy();
  header('Location: index.html');
  exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QualityTime</title>
    <link rel="stylesheet" type="text/css" href="cssPrincipal.css" media="screen" />
    <style>
        .img1 { 
            width: 180px;
            height: 180px;
            display:flex;
            justify-content: center;
            display: inline-block;
            margin-top: 40px;
            margin-left: 80px;
            border-radius: 15px;
            border: 4px solid rgb(112,15,28);
        }
        .img1 a{
            margin-left: 11%; 
            
        }
        .Timgs p{
            padding-left: 33%; 
        }
        p{
            font-weight: bold;
        }
        .img1:hover{
            background-color: rgb(246, 236, 236);
        }
        .Timgs{
            display:flex;
            justify-content: center;
            align-items: center;
        }
        .Timgs2{
            display:flex;
            justify-content: center;
            align-items: center;
        }
        footer {
            background-color: #700F1C;
            color: white;
            padding: 10px 0;
            text-align: center;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <menu>
        <a  href="perfil.php"><input class="fotoPerfil" type="image" src="imagens/avatar.png" style="margin-top: 10px;"></a>
        <h1>Home</h1>
    </menu>
    
    <div class="Timgs">
        <div class="img1">
            <a href="agenda.html"><input type="image" src="imagens/calendar.png" style="margin-top: 10px;"></a>
            <p style="padding-left: 33%;">Agenda</p>
        </div>

        <div class="img1">
            <a href="relatorio.html"><input type="image" src="imagens/document.png" style="margin-top: 10px; margin-left: 8px;"></a>
            <p style="padding-left: 31%;">Relatório</p>
        </div>
        
        <div class="img1">
            <a href="metas.html"><input type="image" src="imagens/paper.png" style="margin-top: 10px; margin-left: 10px;"></a>
            <p style="padding-left: 37%;">Metas</p>
        </div>
        <br>
    </div>
    <div class="Timgs2">
        <div class="img1">
            <a href="pausas.html"><input type="image" src="imagens/pause.png" style="margin-top: 10px; margin-left: 4px;"></a>
            <p style="padding-left: 33%;">Pausas</p>
        </div>
        
        <div class="img1">
            <a href="produtivi.html"><input type="image" src="imagens/produtiv.png" style="margin-top: 10px;"></a>
            <p style="padding-left: 21%; ">Produtividade</p>
        </div> 
    
        <!-- Botão para desconectar -->
        <form action="principal.php" method="POST">
            <input type="hidden" name="logout" value="true">
            <div class="img1">
                <input type="image" src="imagens/sair.png" style="margin-left: 23px;">
                <p style="padding-left: 41%;">Sair</p></div>
        </form>
    </div>

  <?php
    // Verificar se o formulário de logout foi enviado
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
        logout();
    }
  ?>

    <footer>
        &copy; 2023 QualityTime.
    </footer>

  </body>
  </html>
