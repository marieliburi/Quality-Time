<?php
    session_start();

    // Verifica se o usuário está logado
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];

        // Conecta-se ao banco de dados
        $conn = conectarBancoDeDados();

        // Escapa o valor para prevenir SQL injection
        $email = mysqli_real_escape_string($conn, $email);

        // Obtém o tempo inicial do banco de dados associado ao email do usuário
        $sql = "SELECT tempo_inicial FROM pausas WHERE email = '$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $tempoInicial = $row['tempo_inicial'];

            echo $tempoInicial;
        } else {
            // Tempo inicial não encontrado
            echo "";
        }

        // Fecha a conexão com o banco de dados
        desconectarBancoDeDados($conn);
    } else {
        echo "";
    }
?>
