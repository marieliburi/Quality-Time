<?php
    include('conexao.php');
    session_start();

    // Verifica se o usuário está logado
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];

        // Conecta-se ao banco de dados
        $conn = conectarBancoDeDados();

        // Consulta o tempo definido pelo usuário no banco de dados
        $sql = "SELECT tempo FROM pausas WHERE email = '$email'"; 
        $result = $conn->query($sql);

        // Verifica se a consulta foi bem-sucedida
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $tempo = $row["tempo"];
            echo $tempo; // Retorna o tempo definido para o JavaScript
        } else {
            echo "0"; // Retorna 0 caso não haja tempo definido para o usuário
        }

        // Fecha a conexão com o banco de dados
        desconectarBancoDeDados($conn);
    } else {
        echo "";
    }
?>
