<?php
    session_start();
    include('conexao.php');

    // Verifica se o usuário está logado
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];

        // Verifica se os dados foram enviados via POST
        if (isset($_POST['nome']) && isset($_POST['descricao'])) {
            $nome = $_POST['nome'];
            $descricao = $_POST['descricao'];

            // Conecta-se ao banco de dados
            $conn = conectarBancoDeDados();

            // Escapa os valores para prevenir SQL injection
            $nome = mysqli_real_escape_string($conn, $nome);
            $descricao = mysqli_real_escape_string($conn, $descricao);
            $email = mysqli_real_escape_string($conn, $email);

            // Insere a meta no banco de dados associada ao email do usuário
            $sql = "INSERT INTO metas (nome, descricao, email) VALUES ('$nome', '$descricao', '$email')";
            if ($conn->query($sql) === TRUE) {
                echo "Meta salva com sucesso!";
            } else {
                echo "Erro ao salvar a meta: " . $conn->error;
            }

            // Fecha a conexão com o banco de dados
            desconectarBancoDeDados($conn);
        }
    } else {
        echo "Usuário não está logado!";
    }
?>
