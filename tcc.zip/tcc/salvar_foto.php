<?php
session_start();
include('conexao.php');

// Verifica se o usuário está logado
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    // Conecta-se ao banco de dados
    $conn = conectarBancoDeDados();

    // Verifica se um arquivo foi enviado
    if (isset($_FILES['foto_perfil'])) {
        $foto_perfil = file_get_contents($_FILES['foto_perfil']['tmp_name']);

        // Escapa o email para prevenir SQL injection
        $email = mysqli_real_escape_string($conn, $email);

        // Prepara a declaração para atualização
        $stmt = $conn->prepare("UPDATE usuario SET foto_perfil = ? WHERE email = ?");
        $stmt->bind_param("bs", $foto_perfil, $email);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "Imagem de perfil salva com sucesso!";
        } else {
            echo "Erro ao salvar a imagem de perfil.";
        }

        // Fecha a declaração e a conexão com o banco de dados
        $stmt->close();
        $conn->close();
    }
}
?>
