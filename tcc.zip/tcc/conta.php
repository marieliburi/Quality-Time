<?php
    session_start();
    include('conexao.php');

    // Verificar se o usuário já está autenticado
    if (isset($_SESSION['email'])) {
        header('Location: principal.php');
        exit;
    }

    // Verificar se os dados do formulário foram enviados
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Receber os dados do formulário
        $nome = $_POST['nome'];
        $telefone = $_POST['telefone'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];

        // Verificar se o usuário já existe
        $conn = conectarBancoDeDados(); // Função para conectar ao banco de dados

        $sql = "SELECT * FROM usuario WHERE nome = '$nome' OR email = '$email'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            $error = 'Nome de usuário ou e-mail já estão em uso.';
        } else {
            // Inserir novo usuário no banco de dados
            $sql = "INSERT INTO usuario (nome, telefone, email, senha) VALUES ('$nome', '$telefone', '$email', '$senha')";
            if (mysqli_query($conn, $sql)) {
            $_SESSION['email'] = $email;
            header('Location: principal.php');
            exit;
            } else {
            $error = 'Erro ao criar a conta.';
            }
        }

        desconectarBancoDeDados($conn); // Função para desconectar do banco de dados
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QualityTime</title>
    <style>
        :root {
            --input-linear: linear-gradient(120deg, rgb(112,15,28), rgb(112,15,28));
            --light-gray: #cfcfcf;
            --border-height: 1px;
        }
        body{
            margin: 0;
            padding: 0;
            background-color: rgba(237, 230, 230, 0.9);
            font-family: Arial, Helvetica, sans-serif;
        }
        h1{
            color: rgb(112,15,28);
            font-size: 30px;
            text-align: center;
        }
        .container{
            width: 40%;
            height: 600px;
            background-color: rgb(255, 255, 255);
            margin-left: auto;
            margin-right: auto; 
            margin-top: 40px;
            border-radius: 10px ;
            text-align: center;
            box-shadow: 2px 2px 2px 1px rgba(80, 10, 20, 0.584);
        }
        .enviar{
            width: 63%;
            height: 42px;
            font-size: 17px;
            border: 2px solid rgb(112,15,28);
            background-color: rgb(255, 255, 255);
            color: rgb(112,15,28);
            font-weight: bold;
            border-radius: 22px;
        }
        .enviar:hover{
            background-color:rgb(112,15,28) ;
            color:white ;
        }
        form{
            margin-top: 10px;
            margin-left: 0px;
        }
        .login__form {
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .voltar{
            border: none;
            background-color: rgb(246, 246, 246);
            font-size: 15px;
            color: rgb(137, 137, 137);
            text-decoration: none;
        }
        .voltar:hover{
            font-size: 17px;
        }
        label{
            margin-left: -280px;
            font-weight: bold;
            color:rgb(112,15,28);
        }
        .login__input-border {
            height: var(--border-height);
            width: 100%;
            margin-bottom: 16px;
            background: var(--light-gray);
            transition: .3s ease-in-out;
        }
        .login__input-border::after {
            content: '';
            display: block;
            height: var(--border-height);
            width: 0;
            margin-bottom: 16px;
            background: var(--input-linear);
            transition: .3s ease-in-out;
        }
        .login__input {
            width: 60%;
            height: 35px;
            font-size: 17px;
            padding-left: 15px;
            box-sizing: border-box;
            padding-left: 8px;
            border: unset;
            outline: none;
            position: relative;
        }
        .login__input-border {
            height: var(--border-height);
            width: 60%;
            margin-bottom: 16px;
            background: var(--light-gray);
            transition: .3s ease-in-out;
        }
        .login__input-border::after {
            content: '';
            display: block;
            height: var(--border-height);
            width: 0;
            margin-bottom: 16px;
            background: var(--input-linear);
            transition: .3s ease-in-out;
        }
        .login__input:focus + .login__input-border::after {
            width: 100%;
        }
        @media (max-width: 1000px) {
            .container{
                width: 60%;
            }
        }
        @media (max-width: 500px){
            label{
            margin-left: -170px;
            }
            .container{
                width: 80%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <form method="POST" class="login__form">
            <br><h1>Criar conta</h1>
            <label>Nome</label><br>
            <input class="login__input" type="text" name="nome" placeholder="Digite aqui!">
            <span class="login__input-border"></span>
            <label>Telefone</label><br>
            <input class="login__input" type="text" name="telefone" placeholder="Digite aqui!">
            <span class="login__input-border"></span>
            <label>Email</label><br>
            <input class="login__input" type="email" name="email" placeholder="Digite aqui!">
            <span class="login__input-border"></span>
            <label>Senha</label><br>
            <input class="login__input" type="password" name="senha" placeholder="Digite aqui!">
            <span class="login__input-border"></span>
            <input type="submit" class="enviar" value="Enviar"><br><br>
            <a href="index.html" class="voltar">Voltar</a>
        </form>
    </div>
</body>
</html>