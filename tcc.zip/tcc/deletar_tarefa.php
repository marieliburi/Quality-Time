<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    
    session_start();
    include('conexao.php');
    
    // Verifica se o usuário está logado
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];
    
        // Conecta-se ao banco de dados
        $conn = conectarBancoDeDados();
    
        $taskId = $_POST['taskId'];
    
        // Prepara o comando SQL para deletar a tarefa com o ID fornecido
        $sql = "DELETE FROM botoes WHERE id = $taskId"; 
    
        // Executa o comando SQL
        if ($conn->query($sql) === TRUE) {
            echo "Tarefa deletada com sucesso";
        } else {
            echo "Erro ao deletar a tarefa: " . $conn->error;
        }
    
        // Fecha a conexão com o banco de dados
        $conn->close();
    }
    /*
    O botao de deletar nao esta funcionando, não sei pq
    */
    
?>


