<?php
    session_start();
    include('conexao.php');

    // Verificar se o usuário já está autenticado
    if (isset($_SESSION['email'])) {
        header('Location: principal.php');
        exit;
    }

    // Verificar se os dados do formulário foram enviados
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Receber os dados do formulário
        $username = $_POST['email'];
        $password = $_POST['password'];

        // Verificar as credenciais 
        $conn = conectarBancoDeDados(); // Função para conectar ao banco de dados

        // Verificar as credenciais no banco de dados
        $sql = "SELECT * FROM usuario WHERE email = '$username' AND senha = '$password'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {
            // Credenciais válidas, iniciar a sessão
            $_SESSION['email'] = $username;
            header('Location: principal.php');
            exit;
        } else {
            // Credenciais inválidas, exibir mensagem de erro
            $error = 'Nome de usuário ou senha inválidos.';
        }

        // Fechar a conexão com o banco de dados
        desconectarBancoDeDados($conn); // Função para desconectar do banco de dados
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QualityTime</title>
    <style>
        body{
            padding: 0;
            margin: 0;
            background-image: url(imagens/fundoLogin.jpg);
            background-repeat: no-repeat;
            background-size: 100%; 
            background-attachment: fixed;
            font-family:Arial, Helvetica, sans-serif;
        }

        h1{
            color: rgb(112,15,28);
            font-size: 30px;
        }
        .container{
            width: 45%;
            height: 352px;
            background-color: rgb(255, 255, 255);
            margin-left: 33%;
            margin-right: auto; 
            margin-top: 120px;
            text-align: center;
            border-radius:5px ;
        }
        .enviar{
            width: 62%;
            height: 42px;
            border: 2px solid rgb(112,15,28);
            background-color: white;
            color: rgb(112,15,28);
            font-weight: bold;
            border-radius: 22px;
        }
        .enviar:hover{
            background-color:rgb(112,15,28) ;
            color:white ;
            transition: 0.5;
        }
        form input{
            width: 60%;
            height: 35px;
            font-size: 17px;
            padding-left: 10px;
            border: 2px solid rgb(112,15,28);
            border-radius: 22px;
        }
        img{
            width: 500px;
            height: 500px;
            border-radius: 5px;
        }
        .img-mulher{
            width: 100px;
            height: 100px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        form{
            margin-top: -75px;
            margin-left: 150px;
        }
        .voltar, .esqueceu{
            border: none;
            background-color: white;
            font-size: 15px;
            color: rgb(137, 137, 137);
            text-decoration: none;
            margin-top: 3px;
        }
        .voltar:hover, .esqueceu:hover{
            font-size: 17px;
        }
        @media (max-width: 800px) {
            .img-mulher{
                visibility: hidden;
            }
            form{
                margin-top: -55px;
                margin-left: 0px;
            }
    }
    @media (max-width: 600px) {
        body{
            background-image: url(null);
            background-color: #700F1C;
        }
        .container{
            width: 60%;
            height: 352px;
            margin-left: 23%;
            margin-right: auto; 
            margin-top: 120px;
            text-align: center;
            border-radius:5px ;
        }
    }
    </style>
</head>
<body>
    <div class="container">
        <div class="img-mulher">
            <img src="imagens/mulher.png">
        </div>
        <form method="POST">
            <h1>Login</h1>
            <input type="email" id="email" name="email" placeholder="Email"><br><br>
            <input type="password" id="password" name="password" placeholder="Senha"><br><br>
            <input type="submit" class="enviar" value="Entrar"><br><br>
            <a href="index.html" class="voltar">Voltar</a><br>
            
        </form>
    </div>
</body>
</html>