<?php
    // Inicie a sessão para ter acesso às informações do usuário logado
    session_start();
    include('conexao.php');

    // Verifica se o usuário está logado
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];

        // Conecta-se ao banco de dados (utilize o seu próprio código de conexão)
        $conn = conectarBancoDeDados();

        // Escapa o email para prevenir SQL injection
        $email = mysqli_real_escape_string($conn, $email);

        // Consulta o banco de dados para obter os dados do usuário
        $query = "SELECT nome, telefone, email FROM usuario WHERE email = '$email'";
        $result = mysqli_query($conn, $query);

        // Verifica se a consulta foi bem-sucedida
        if ($result) {
            $row = mysqli_fetch_assoc($result);
            $nome = $row['nome'];
            $telefone = $row['telefone'];
            $email = $row['email'];

            // Cria um array com os dados do usuário
            $response = array(
                'success' => true,
                'nome' => $nome,
                'telefone' => $telefone,
                'email' => $email
            );

            // Retorna os dados em formato JSON
            echo json_encode($response);
        } else {
            // Erro ao consultar os dados do usuário
            $response = array('success' => false);
            echo json_encode($response);
        }

        // Fecha a conexão com o banco de dados
        mysqli_close($conn);
    }
?>