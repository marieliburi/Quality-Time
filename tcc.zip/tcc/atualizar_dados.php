<?php
// Inicia a sessão para obter o email do usuário logado
session_start();

// Verifica se o usuário está logado
if (isset($_SESSION['email'])) {
    // Inclui o arquivo de conexão com o banco de dados
    include('conexao.php');
    
    // Obtém o email do usuário logado
    $email = $_SESSION['email'];

    // Obtém os dados enviados via POST
    $nome = $_POST['nome'];
    $telefone = $_POST['telefone'];
    $senha = $_POST['senha'];

    // Conecta-se ao banco de dados
    $conn = conectarBancoDeDados();

    // Escapa os dados recebidos para evitar SQL injection
    $nome = mysqli_real_escape_string($conn, $nome);
    $telefone = mysqli_real_escape_string($conn, $telefone);
    $senha = mysqli_real_escape_string($conn, $senha);

    // Atualiza os dados na tabela do usuário
    $sql = "UPDATE usuario SET nome = '$nome', telefone = '$telefone', senha = '$senha' WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Dados atualizados com sucesso
        $response = array(
            'success' => true,
            'nome' => $nome,
            'telefone' => $telefone
            // Adicione aqui outras informações que você deseja retornar
        );
        echo json_encode($response);
    } else {
        // Erro ao atualizar os dados
        $response = array('success' => false);
        echo json_encode($response);
    }

    // Fecha a conexão com o banco de dados
    mysqli_close($conn);
}
?>
