<?php
    session_start();
    include('conexao.php');

    // Verifica se o usuário está logado
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];

        // Conecta-se ao banco de dados
        $conn = conectarBancoDeDados();

        // Escapa o email para prevenir SQL injection
        $email = mysqli_real_escape_string($conn, $email);

        // Seleciona as tarefas do banco de dados associadas ao email do usuário
        $sql = "SELECT * FROM metas WHERE email = '$email'";
        $result = $conn->query($sql);

        // Cria um array para armazenar as tarefas
        $tarefas = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $tarefa = array(
                    'nome' => $row['nome'],
                    'descricao' => $row['descricao']
                );
                $tarefas[] = $tarefa;
            }
        }

        // Fecha a conexão com o banco de dados
        desconectarBancoDeDados($conn);

        // Retorna as tarefas em formato JSON
        echo json_encode($tarefas);
    } else {
        echo "Usuário não está logado!";
    }
?>
