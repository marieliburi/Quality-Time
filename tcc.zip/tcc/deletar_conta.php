<?php
session_start();
include('conexao.php');

// Verifica se o usuário está logado
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    // Conecta-se ao banco de dados
    $conn = conectarBancoDeDados();

    // Escapa $result = mysqli_query($conn, $sql);o email para prevenir SQL injection
    $email = mysqli_real_escape_string($conn, $email);

    // Deleta a conta do usuário da tabela
    $sql = "DELETE FROM usuario WHERE email = '$email'";
    

    if ($result) {
        // Conta deletada com sucesso
        // Encaminha o usuário para a página inicial de entrada (index.html)
        session_destroy(); // Destroi a sessão
        echo json_encode(array('success' => true));
    } else {
        // Erro ao deletar a conta
        echo json_encode(array('success' => false));
    }

    // Fecha a conexão com o banco de dados
    mysqli_close($conn);
}
?>
